# Tests

- `e2e/`: Androidの主要フロー。
- `fixtures/`: 再現可能な手札、場、昼夜、効果状態。
- `load/`: Realtime、同時接続、対局イベント負荷。

失敗時に乱数seed、対局ID、状態版、端末条件を記録します。

