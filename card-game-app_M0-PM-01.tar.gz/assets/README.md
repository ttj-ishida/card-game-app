# Assets

- `runtime/`: アプリで使用する最適化済み画像・音声。
- `manifests/`: 安定ID、版、ファイル、寸法、ハッシュの対応表。
- `source-manifests/`: 大容量制作元の所在、版、権利情報。

表示名をファイル名へ使用せず、`CONTRIBUTING.md`の安定ID命名へ従います。

