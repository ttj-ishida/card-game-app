# Supabase

M0-SB-02でSupabase CLIを初期化します。DB変更はマイグレーションとして記録し、空環境から再現できる状態を維持します。

- `migrations/`: DB構造とRLS
- `functions/`: Edge Functions
- `tests/`: SQL、RLS、トランザクションテスト
- `seed.sql`: 非秘密の開発用マスタ

