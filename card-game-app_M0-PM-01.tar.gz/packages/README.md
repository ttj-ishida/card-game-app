# Packages

- `game-core/`: UI、ネットワーク、永続化へ依存しない対局ルール。
- `contracts/`: クライアントとサーバーで共有する状態、要求、イベント型。
- `ui/`: デザイントークンと共有UI部品。

package間に循環依存を作りません。`game-core`はExpo・Supabase SDKをimportしません。

