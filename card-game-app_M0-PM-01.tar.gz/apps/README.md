# Apps

- `mobile/`: M0-EX-01で作成するExpo Androidアプリ。
- `invite-landing/`: M4で作成するHTTPS招待案内ページ。

各アプリ固有のEAS設定や公開設定は、そのアプリ直下へ置きます。

